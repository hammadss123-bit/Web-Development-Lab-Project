-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- مضيف: 127.0.0.1
-- وقت الجيل: 15 نوفمبر 2026 الساعة 15:55
-- إصدار الخادم: 10.11.16-MariaDB
-- نسخة PHP: 8.3.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- قاعدة بيانات: `portfolio_db`
--

-- --------------------------------------------------------

--
-- بنية الجدول `portfolio_info`
--

CREATE TABLE `portfolio_info` (
  `id` int(11) NOT NULL,
  `section_key` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `portfolio_info`
--

INSERT INTO `portfolio_info` (`id`, `section_key`, `title`, `content`) VALUES
(1, 'home', 'أيوب حماد صنت صنهات', 'طالب هندسة برمجيات في السنة الرابعة بجامعة حائل، كلية علوم وهندسة الحاسب الآلي.'),
(2, 'about', 'نبذة تعريفية', 'طالب هندسة برمجيات في السنة الرابعة بجامعة حائل، كلية علوم وهندسة الحاسب الآلي. أمتلك اهتمامًا بمجال البرمجة وتقنية المعلومات، وأسعى إلى تطوير مهاراتي الأكاديمية والعملية واكتساب الخبرات في المجال التقني. أعمل خلال الفترة المسائية فني صيانة ومبرمجًا في محل ومضة حائل، مما أتاح لي الجمع بين الدراسة الجامعية والتطبيق العملي واكتساب الخبرة في التعامل مع المشكلات التقنية.'),
(3, 'education', 'المؤهل العلمي', 'الجامعة: جامعة حائل<br>الكلية: كلية علوم وهندسة الحاسب الآلي<br>التخصص: هندسة البرمجيات<br>المستوى الدراسي: السنة الرابعة'),
(4, 'experience', 'الخبرات العملية', 'فني صيانة ومبرمج – محل ومضة حائل<br>- العمل في مجال صيانة الأجهزة.<br>- تنفيذ أعمال البرمجة والدعم التقني.<br>- تشخيص المشكلات التقنية والعمل على حلها.<br>- اكتساب الخبرة العملية في التعامل مع الأجهزة والبرمجيات.'),
(5, 'skills', 'المهارات', '• البرمجة وتطوير البرمجيات<br>• صيانة الأجهزة<br>• حل المشكلات التقنية<br>• التفكير التحليلي<br>• التعلم المستمر وتطوير المهارات<br>• العمل ضمن فريق وإدارة الوقت'),
(6, 'goal', 'الهدف المهني', 'تطوير مسيرتي المهنية في مجال هندسة البرمجيات وتقنية المعلومات، والاستفادة من معرفتي الأكاديمية وخبرتي العملية للمساهمة في بناء حلول تقنية مبتكرة وفعّالة.');

--
-- Indexes for dumped tables
--

--
-- فهارس للجدول `portfolio_info`
--
ALTER TABLE `portfolio_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `portfolio_info`
--
ALTER TABLE `portfolio_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
